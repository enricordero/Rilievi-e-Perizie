import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { Geolocation } from '@capacitor/geolocation';

declare function inviaRichiesta(
  method: string,
  url: string,
  params: Record<string, any>
): Promise<{ status: number; data?: any; err?: any }>;

declare function base64Convert(blob: Blob): Promise<string>;

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [IonHeader, IonToolbar, IonTitle, IonContent],
})
export class HomePage {
  showLogin = true
  showChangePassword = false
  showMainSection = false
  username = ""
  id = ""
  coordinate = {}
  base64 = ""
  fotografie: { url: string; commento: string }[] = []

  async onAccedi() {
    let username = (document.getElementById("username") as HTMLInputElement).value;
    let password = (document.getElementById("password") as HTMLInputElement).value;
    const request = await inviaRichiesta("POST", "/api/loginUtenti", { username, password })
    if (request.status == 200) {
      this.showLogin = false;
      this.username = request.data.utente.username
      if (password == "password") {
        this.showChangePassword = true;
      }
      else {
        this.showMainSection = true;
        this.id = request.data.utente.id
      }
    }
    else if (request.status == 401) {
      alert("Password sbagliata")
    }
    else if (request.status == 403) {
      alert("Accesso riservato agli operatori")
    }
    else {
      alert("Utente non riconosciuto")
    }
  }

  async onConferma() {
    let newPassword = (document.getElementById("newPassword") as HTMLInputElement).value;
    let confirmNewPassword = (document.getElementById("confirmNewPassword") as HTMLInputElement).value;
    console.log(newPassword, confirmNewPassword)
    if (newPassword == confirmNewPassword) {
      if (newPassword == "password") {
        alert("La password non può essere 'password'")
      }
      if (newPassword.length >= 8) {
        const request = await inviaRichiesta("POST", "/api/cambiaPassword", { username: this.username, newPassword })
        if (request.status == 200) {
          this.showLogin = true;
          this.showChangePassword = false;
        }
      }
      else {
        alert("La password deve essere lunga almeno 8 caratteri")
      }
    }
    else {
      alert("Le password non corrispondono")
    }
  }

  onCaricaImmagini() {
    const input = document.getElementById("caricaFoto") as HTMLInputElement | null;
    const divAnteprima = document.getElementById("previewContainer");
  
    if (input && input.files && divAnteprima) {
      const files = Array.from(input.files);
      const estensioniAccettate = ['.jpg', '.jpeg', '.png', '.gif', '.svg'];
      const fileNonValidi: string[] = [];
      divAnteprima.innerHTML = '';
      this.fotografie = [];
  
      for (const file of files) {
        const estensioneFile = file.name.split('.').pop()?.toLowerCase();
        if (estensioneFile && !estensioniAccettate.includes(`.${estensioneFile}`)) {
          fileNonValidi.push(file.name);
        } else {
          const fileReader = new FileReader();
          fileReader.onload = (event) => {
            const fullBase64 = event.target?.result as string;
            const base64Only = fullBase64.split(',')[1];
  
            const div = document.createElement("div");
            div.classList.add("file-preview");
  
            const imgAnteprima = document.createElement("img");
            imgAnteprima.src = fullBase64;
            imgAnteprima.alt = file.name;
            imgAnteprima.style.maxWidth = "200px";
  
            const br = document.createElement("br");
            const commento = document.createElement("textarea");
            commento.placeholder = "Aggiungi un commento";
            commento.style.width = "50%";
            commento.style.marginTop = "10px";

            commento.addEventListener("input", () => {
              const index = this.fotografie.findIndex(f => f.url === base64Only);
              if (index !== -1) {
                this.fotografie[index].commento = commento.value;
              }
              console.log(commento)
            });
  
            this.fotografie.push({
              url: base64Only,
              commento: ""
            });
            
  
            div.appendChild(imgAnteprima);
            div.appendChild(br);
            div.appendChild(commento);
  
            divAnteprima.appendChild(div);
          };
  
          fileReader.readAsDataURL(file);
        }
      }
  
      if (fileNonValidi.length > 0) {
        alert("I seguenti file non sono validi: \n" + fileNonValidi.join(', '));
      }
    }
  }
  

  async onCaricaPerizia() {
    try {
      const permResult = await Geolocation.requestPermissions();
      if (permResult.location !== 'granted') {
        alert('Permesso negato');
        return;
      }
  
      const position = await Geolocation.getCurrentPosition();
      const lat = position.coords.latitude;
      const lng = position.coords.longitude;
      this.coordinate = { lat, lng };
  
      this.creaPerizia();
  
    } catch (error) {
      alert('Errore durante la geolocalizzazione');
      console.error(error);
    }
  }
  
  async creaPerizia() {
    const descrizione = (document.getElementById("descrizione") as HTMLInputElement).value;
  
    const perizia = {
      idUtente: this.id,
      dataOra: new Date().toISOString(),
      coordinate: this.coordinate,
      descrizione: descrizione,
      fotografie: this.fotografie
    };

    const request = await inviaRichiesta("POST", "/api/creaPerizia", { perizia })
    if(request.status == 201 || request.status == 200){
      alert("Perizia creata con successo");
    }
  
    console.log(perizia);
  }
}
